# coding: utf-8

# Import the Apex "remoting" module - this enables Apex to be launched form your script
import remoting

# Launch the Apex application
remoting.launchApplication(appName='Apex')


# Standard Apex imports
import apex
from apex.construct import Point3D, Point2D

# Import modules needed for this demo
import sys
import math

# Set the scripting units system...    
apex.setScriptUnitSystem(unitSystemName = r'''m-kg-s-N''')

# Retrieve the current Model and reset to an empty model
model = apex.currentModel()
model = model.close()


# Define the geometry file to import
# NOTE : Modify the location to match the location of this file on your machine
geometryFileNames = [r"C:\Demo\Front_Suspension_CAD.X_T"]
model.importGeometry(
    geometryFileNames = geometryFileNames,
    importSolids = True,     #defaults to True
    importSurfaces = True,     #defaults to True
    importCurves = True,     #defaults to True
    importPoints = True,     #defaults to True
    importGeneralBodies = True,     #defaults to True
    importHiddenGeometry = False,     #defaults to False
    cleanOnImport = True,     #defaults to True
    removeRedundantTopoOnimport = False,     #defaults to True
    sewOnImport = False     #defaults to False
)


# Define a highlight color - we'll use this to identify "Large" solids
solidHighlightColor = apex.ColorRGB(214, 255, 0)

# Get all of the Parts in the current model
parts = model.getParts(recursive=True)

# Process all of the 
solid_volumes = {}
for part in parts:
    solids = part.solids
    for solid in solids:
        if solid.volume < 0.0001:
            print(solid.name + ", " + str(solid.volume) + " is small")
        else:
            print(solid.name + ", " + str(solid.volume) + " is large")                
            solid.highlight(colorRGB = solidHighlightColor, lineWidth = 2, pointSize = 3)
            
# Shot down the Apex application before exiting            
remoting.shutdownApplication()            